/*
    Assignment 3 - Scrollable Course List

    DataSource.kt

    Dhaya Raja / rajadh@oregonstate.edu
    CS 492 / Oregon State University
 */

package com.example.scrollablecourselist.data

import com.example.scrollablecourselist.R
import com.example.scrollablecourselist.model.Course

object DataSource {
    val courses = listOf(
        Course(R.string.my_name, R.string.department_assignment, 3, 1),

        // CS Department courses
        Course(R.string.cs_161_title, R.string.department_cs, 161, 100),
        Course(R.string.cs_162_title, R.string.department_cs, 162, 100),
        Course(R.string.cs_225_title, R.string.department_cs, 225, 200),
        Course(R.string.cs_261_title, R.string.department_cs, 261, 200),
        Course(R.string.cs_271_title, R.string.department_cs, 271, 200),
        Course(R.string.cs_290_title, R.string.department_cs, 290, 200),
        Course(R.string.cs_325_title, R.string.department_cs, 325, 300),
        Course(R.string.cs_340_title, R.string.department_cs, 340, 300),
        Course(R.string.cs_344_title, R.string.department_cs, 344, 300),
        Course(R.string.cs_361_title, R.string.department_cs, 361, 300),
        Course(R.string.cs_362_title, R.string.department_cs, 362, 300),
        Course(R.string.cs_467_title, R.string.department_cs, 467, 400)
    )
}