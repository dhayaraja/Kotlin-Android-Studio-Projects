/*
    Assignment 3 - Scrollable Course List

    Course.kt

    Dhaya Raja / rajadh@oregonstate.edu
    CS 492 / Oregon State University
 */

package com.example.scrollablecourselist.model

data class Course(
    val title: Int,       // references the title from strings.xml
    val department: Int, // references the department code
    val number: Int,    // references the course number
    val capacity: Int   // references the max number of students (rounded down to its 100s)
)